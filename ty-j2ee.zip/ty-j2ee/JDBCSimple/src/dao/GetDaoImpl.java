package dao;

public class GetDaoImpl {
String type = "jdbc";

public EmployeeDao getDaoImpl() {
	if(type.equalsIgnoreCase("jdbc")) {
		return new EmployeeDAOJDBCImple();
	}
	if(type.equalsIgnoreCase("hibernate")) {
		return new EmployeeJDBCHibernatrImpl();
	}
	if(type.equalsIgnoreCase("spring")) {
		return new EmployeeJDBCSpringImpl();
	}
	return null;
}
}
