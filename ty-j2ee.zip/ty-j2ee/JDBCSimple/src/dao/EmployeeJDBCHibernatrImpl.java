package dao;

import bean.EmployeeData;

public class EmployeeJDBCHibernatrImpl  implements EmployeeDao{

	@Override
	public EmployeeData getSingleRecord(int id) {
		System.out.println("hibernate imlpe");
		return null;
	}

	@Override
	public void getAllRecord() {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void insertRecord(EmployeeData a) {
		// TODO Auto-generated method stub
		
	}

}
