package dao;

import java.io.FileInputStream;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.Statement;
import java.util.Properties;

import bean.EmployeeData;

public class EmployeeDAOJDBCImple implements EmployeeDao{

	EmployeeData emp = new EmployeeData();

	@Override
	public EmployeeData getSingleRecord(int id) {
		try {
		   FileInputStream fis = new FileInputStream("properties.properties");
		    Properties p = new Properties();
		    p.load(fis);
	Connection	con=DriverManager.getConnection(p.getProperty("dburl"), p.getProperty("user"),p.getProperty("pw"));
		String q = "select * from employeedata where id="+id+";";
	Statement	stmt=con.createStatement();
		 ResultSet rs =stmt.executeQuery(q);
		while(rs.next()) {
			emp.setEmpid(rs.getInt("id"));
			emp.setName(rs.getString("name"));
			emp.setSalary(rs.getInt("sal"));
			emp.setDoj(rs.getDate("doj"));
		}
		
			
		
	} catch (Exception e) {
		e.printStackTrace();
	}
		return emp;
	}

	@Override
	public void getAllRecord() {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void insertRecord(EmployeeData a) {
		// TODO Auto-generated method stub
		
	}

}
