package dao;

import bean.EmployeeData;

public interface EmployeeDao {
  public EmployeeData getSingleRecord(int id);
  public void getAllRecord();
  public void insertRecord(EmployeeData a);
}
