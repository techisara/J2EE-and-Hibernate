package services;

import bean.EmployeeData;
import dao.EmployeeDao;
import dao.GetDaoImpl;

public class EmployeeServiceImpl implements EmployeeService {

	GetDaoImpl daoImpl = new GetDaoImpl();
	EmployeeDao dao = daoImpl.getDaoImpl();
	
	@Override
	public EmployeeData getSingleRecord(int id) {
       if(id<0) {
		return null;
       }
       else {
    	   System.out.println("employee service layer");
    	   return dao.getSingleRecord(id);
       }
	}

	@Override
	public void getAllRecords() {
		// TODO Auto-generated method stub
		System.out.println("featching all records");
	}

	@Override
	public void insertRecord(EmployeeData a) {
		// TODO Auto-generated method stub
		System.out.println("inserted");
	}

}
