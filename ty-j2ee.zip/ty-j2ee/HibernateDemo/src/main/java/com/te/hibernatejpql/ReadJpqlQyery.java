package com.te.hibernatejpql;

import java.util.Iterator;
import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.EntityTransaction;
import javax.persistence.Persistence;
import javax.persistence.Query;

import com.te.hibernatejpa.bean.Movies;

public class ReadJpqlQyery {

	public static void main(String[] args) {

		
		
		EntityManagerFactory emf = null;
		EntityManager em = null;
	
		
		try {
			emf=Persistence.createEntityManagerFactory("Moviedata");
			em=emf.createEntityManager();
			
			
			
//			 String s = "from Movies";
//			 Query q = em.createQuery(s);
//			 List<Movies> movieList = q.getResultList();
//			 
//			 System.out.println(movieList);
//			 
//			 for (Movies m : movieList) {
//				 System.out.println(m.getId());
//				 System.out.println(m.getName());
//				 System.out.println(m.getHero());
//				 System.out.println(m.getRating());
//				
//			}
			
			
			
			String s = "from Movies where id =10";
			 Query q = em.createQuery(s);
			 Movies movie =(Movies) q.getSingleResult();
			 System.out.println(movie.getId());
			 System.out.println(movie.getName());
			 System.out.println(movie.getHero());
			 System.out.println(movie.getRating());
			 
	}catch (Exception e) {
       
       e.printStackTrace();
	}finally {
		emf.close();
		em.close();
	}

		
	}

}
