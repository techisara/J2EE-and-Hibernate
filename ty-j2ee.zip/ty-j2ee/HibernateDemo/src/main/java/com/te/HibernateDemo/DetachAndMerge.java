package com.te.HibernateDemo;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.EntityTransaction;
import javax.persistence.Persistence;

import com.te.hibernatejpa.bean.Movies;

public class DetachAndMerge {

	public static void main(String[] args) {
		EntityManagerFactory emf = null;
		EntityManager entityManger = null;
		EntityTransaction entityTransaction=null;
		
		try {
			
			emf=Persistence.createEntityManagerFactory("Moviedata");
			entityManger=emf.createEntityManager();
			 entityTransaction=entityManger.getTransaction();
			 
			 entityTransaction.begin();
			 Movies movies=entityManger.find(Movies.class, 10);
			 
			 System.out.println("before detach");
			 
			System.out.println(entityManger.contains(movies));
			System.out.println("after detach");
			entityManger.detach(movies);
			System.out.println(entityManger.contains(movies));
			
			
			Movies mov =entityManger.merge(movies);
			System.out.println(entityManger.contains(mov));

			
			
		} catch (Exception e) {
		
		
		}
	}

}
