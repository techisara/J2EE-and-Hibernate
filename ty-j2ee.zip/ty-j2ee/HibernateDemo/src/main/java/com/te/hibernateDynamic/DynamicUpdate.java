package com.te.hibernateDynamic;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.EntityTransaction;
import javax.persistence.Persistence;
import javax.persistence.Query;

import com.te.hibernatejpa.bean.Movies;

public class DynamicUpdate {

	public static void main(String[] args) {

		EntityManagerFactory entityMangerFactory = null;
		EntityManager entityManger = null;
		EntityTransaction transaction=null;
		
		try {
			entityMangerFactory=Persistence.createEntityManagerFactory("Moviedata");
			entityManger=entityMangerFactory.createEntityManager();
			 transaction=entityManger.getTransaction();
			 
			 transaction.begin();
	
	        String q = "update Movies set name=:name, rating=:rating where id =:id";	
		     Query query = entityManger.createNativeQuery(q);
		     query.setParameter("id",Integer.parseInt(args[0]));
		     query.setParameter("name",(args[1]));
		     query.setParameter("rating",Double.parseDouble(args[2]));
		     
		     
//		     query.setParameter("id",sc.nextInt());
//		     query.setParameter("name",sc.next());
//		     query.setParameter("rating",sc.nextDouble());
		     
		     int n = query.executeUpdate();
		     System.out.println(n+" no rows affected");
		
			 transaction.commit();
		} catch (Exception e) {
          if(transaction!=null) {
        	  transaction.rollback();
        	  System.out.println("rollBaced");
          }
          e.printStackTrace();
          
          
		
		}finally {
			entityMangerFactory.close();
			entityManger.close();
		}
		
		
	}

}
