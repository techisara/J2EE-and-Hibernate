package com.te.hibernatejpql;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.EntityTransaction;
import javax.persistence.Persistence;
import javax.persistence.Query;

public class ReadNumberOfRecords {

	public static void main(String[] args) {
		EntityManagerFactory emf = null;
		EntityManager em = null;
		EntityTransaction et = null;
	
		
		try {
			emf=Persistence.createEntityManagerFactory("Moviedata");
			em=emf.createEntityManager();
			et = em.getTransaction();
			
			et.begin();
			String q = "select count(*) from Movies";
			Query query = em.createQuery(q);
			long n = (long)query.getSingleResult();
			System.out.println(n+" are the number of object in Movie table");
			
			
			et.commit();
			
		}catch (Exception e) {
            if(et!=null) {
            	et.rollback();
            	System.out.println("roll back");
            }
		
		}finally {
			if(em!=null) {
				em.close();
			}
			if(emf!=null) {
				emf.close();
			}
		}

	}

}
