package com.te.HibernateDemo;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.EntityTransaction;
import javax.persistence.Persistence;

import com.te.hibernatejpa.bean.Movies;

public class Deletemovie {

	public static void main(String[] args) {
		EntityManagerFactory emf = null;
		EntityManager em = null;
		EntityTransaction t=null;
		
		try {
			emf=Persistence.createEntityManagerFactory("Moviedata");
			em=emf.createEntityManager();
			 t=em.getTransaction();
			 
			 t.begin();
			 Movies movie = em.find(Movies.class, 60);
			
			 em.remove(movie);
			  t.commit();
			 
	}catch (Exception e) {
       if(t!=null) {
    	   t.rollback();
    	   System.out.println("roll baked");
       }
       e.printStackTrace();
	}finally {
		emf.close();
		em.close();
	}

}
}
