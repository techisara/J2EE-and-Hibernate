package com.te.HibernateDemo;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.EntityTransaction;
import javax.persistence.Persistence;

import com.te.hibernatejpa.bean.Movies;

public class UpdateName {

	public static void main(String[] args) {
		EntityManagerFactory entityMangerFactory = null;
		EntityManager entityManger = null;
		EntityTransaction transaction=null;
		
		try {
			entityMangerFactory=Persistence.createEntityManagerFactory("Moviedata");
			entityManger=entityMangerFactory.createEntityManager();
			 transaction=entityManger.getTransaction();
			 
			 transaction.begin();
			 Movies movie = entityManger.find(Movies.class, 30);
			 
			 if(movie!=null) {
				 movie.setName("catcf");
			 }
			 transaction.commit();
		} catch (Exception e) {
          if(transaction!=null) {
        	  transaction.rollback();
        	  System.out.println("rollBaced");
          }
          e.printStackTrace();
          
          
		
		}finally {
			entityMangerFactory.close();
			entityManger.close();
		}
		
		
	}

}
