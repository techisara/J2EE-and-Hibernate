package com.te.hibernatejpa.bean;

import java.io.Serializable;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;

import lombok.Data;





@Data
@Entity
//@Table(name="movie_info")
public class Movies implements Serializable {
    /**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	@Id
    @Column
	private int id;
    @Column    
    private String name;
    @Column
    private String hero;
    @Column
    private double rating;

    
    

}
