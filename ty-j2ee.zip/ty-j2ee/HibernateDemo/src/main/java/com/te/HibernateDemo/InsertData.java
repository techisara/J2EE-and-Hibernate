package com.te.HibernateDemo;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.EntityTransaction;
import javax.persistence.Persistence;

import com.te.hibernatejpa.bean.Movies;

public class InsertData {

	public static void main(String[] args) {

		Movies movies = new Movies();
		movies.setId(60);
		movies.setName("wanted");
		movies.setHero("salemon khan");
		movies.setRating(9.5);
		
		EntityManagerFactory entityMangerFactory = null;
		EntityManager entityManger = null;
		EntityTransaction transaction=null;
		 
		try {
		entityMangerFactory=Persistence.createEntityManagerFactory("Moviedata");
		entityManger=entityMangerFactory.createEntityManager();
		 transaction=entityManger.getTransaction();
		 
		 
		 transaction.begin();
		 
		 entityManger.persist(movies);
		 System.out.println("inserted data in to table");
		 transaction.commit();
		
		}catch (Exception e) {
          if(transaction!=null) {
        	  transaction.rollback();
        	  System.out.println("rollbacked data");
          }
		}
		
	}

}
