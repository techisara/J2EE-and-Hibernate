package com.te.hibernateDynamic;

import java.util.Scanner;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.EntityTransaction;
import javax.persistence.Persistence;

import com.te.hibernatejpa.bean.Movies;

public class Dynamicinsert {

	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in).useDelimiter("\n");
		
		Movies movies = new Movies();
		System.out.println("enter");
		movies.setId(sc.nextInt());
		System.out.println("enter");
		movies.setName(sc.next());
		
		System.out.println("enter");
		
		movies.setHero(sc.next());
		System.out.println("enter");
		movies.setRating(sc.nextDouble());
		
		EntityManagerFactory entityMangerFactory = null;
		EntityManager entityManger = null;
		EntityTransaction transaction=null;
		 
		try {
		entityMangerFactory=Persistence.createEntityManagerFactory("Moviedata");
		entityManger=entityMangerFactory.createEntityManager();
		 transaction=entityManger.getTransaction();
		 
		 
		 transaction.begin();
		 
		 entityManger.persist(movies);
		 System.out.println("inserted data in to table");
		 transaction.commit();
		
		}catch (Exception e) {
          if(transaction!=null) {
        	  transaction.rollback();
        	  System.out.println("rollbacked data");
          }
		}
		
	}

}
