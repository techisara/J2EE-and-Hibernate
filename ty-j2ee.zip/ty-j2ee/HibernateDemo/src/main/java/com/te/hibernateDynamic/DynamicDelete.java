package com.te.hibernateDynamic;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.EntityTransaction;
import javax.persistence.Persistence;
import javax.persistence.Query;

public class DynamicDelete {

	public static void main(String[] args) {
		EntityManagerFactory entityMangerFactory = null;
		EntityManager entityManger = null;
		EntityTransaction transaction=null;
		
		try {
			entityMangerFactory=Persistence.createEntityManagerFactory("Moviedata");
			entityManger=entityMangerFactory.createEntityManager();
			 transaction=entityManger.getTransaction();
			 
			 transaction.begin();
	
	        String q = "delete from  Movies  where id =:id";	
		     Query query = entityManger.createQuery(q);
		     query.setParameter("id",Integer.parseInt(args[0]));
		     
		     int n = query.executeUpdate();
		     System.out.println(n+" no rows affected");
		
			 transaction.commit();
		} catch (Exception e) {
          if(transaction!=null) {
        	  transaction.rollback();
        	  System.out.println("roll back");
          }
          e.printStackTrace();
          
          
		
		}finally {
			entityMangerFactory.close();
			entityManger.close();
		}
		
		
	}

}
