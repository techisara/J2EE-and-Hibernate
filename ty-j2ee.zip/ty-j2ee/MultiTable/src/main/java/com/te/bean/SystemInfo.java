package com.te.bean;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.OneToOne;

import lombok.Data;

@Data
@Entity
public class SystemInfo {
	@Id
	@Column
private int sid;
	@Column
private String brand;
	@OneToOne(cascade=CascadeType.ALL)
private Employee employee;
}
