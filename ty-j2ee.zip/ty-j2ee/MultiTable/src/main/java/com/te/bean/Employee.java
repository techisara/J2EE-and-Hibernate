package com.te.bean;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.OneToOne;

import lombok.Data;
@Data
@Entity
public class Employee {
	@Id
	@Column
private int eid;
	@Column
private String ename;
	
	@OneToOne(cascade=CascadeType.ALL)
     @JoinColumn(name="sid")
	private SystemInfo systeminfo;
}
