package com.te.jdbc;

import java.io.FileInputStream;
import java.sql.Connection;
import java.sql.Date;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.Properties;

public class DynamicInsert {

	public static void main(String[] data) {
		Connection con = null;
	      PreparedStatement ps = null;
	      ResultSet rs=null;
	      DateFormat dateformate = new SimpleDateFormat("yyyy-mm-dd");
	       
		   FileInputStream fis;
			try {
				fis = new FileInputStream("properties.properties");
				 Properties p = new Properties();
			   	    p.load(fis);
			   	con=DriverManager.getConnection(p.getProperty("dburl"), p.getProperty("user"),p.getProperty("pw"));
			} catch (Exception e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			 
	       
	      
	       try {
	    	   String q = "insert into employeedata value(?,?,?,?);";
	           
			ps=con.prepareStatement(q);
			
			 ps.setInt(1,Integer.parseInt(data[0]));
			 ps.setString(2,data[1]);
			 ps.setInt(3,Integer.parseInt(data[2]));
			 ps.setString(4,dateformate.format(data[3]));
			
			rs=ps.executeQuery();
			if(rs!=null) {
				System.out.println("insert succesfull");
			}
		
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	       
	       
	       finally {
				if(ps!=null)
				{
					try {
						ps.close();
					} catch (SQLException e) {
						e.printStackTrace();
					}
				}
				if(con!=null)
				{
					try {
						con.close();
					} catch (SQLException e) {
						e.printStackTrace();
					}
				}
			}
	}

}
