package com.te.jdbc;

import java.io.FileInputStream;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.Properties;

public class updateDemo {

	public static void main(String[] args) {

		 Connection con = null;
	      Statement stmt = null;
	      
	      
	   	   FileInputStream fis;
		try {
			fis = new FileInputStream("properties.properties");
			 Properties p = new Properties();
		   	    p.load(fis);
		   	con=DriverManager.getConnection(p.getProperty("dburl"), p.getProperty("user"),p.getProperty("pw"));
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
	    
	    try {
	 	   String q = "update employeedata set name='mishi' where id=2;";
	        
			stmt=con.createStatement();
			
			int n = stmt.executeUpdate(q);
			System.out.println(n+"number of query affected");
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	    
	    
	    finally {
				if(stmt!=null)
				{
					try {
						stmt.close();
					} catch (SQLException e) {
						e.printStackTrace();
					}
				}
				if(con!=null)
				{
					try {
						con.close();
					} catch (SQLException e) {
						e.printStackTrace();
					}
				}
			}

		
	}

}
