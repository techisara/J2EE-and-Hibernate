package com.te.jdbc;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;
import java.sql.Statement;

public class InsertStatic {

	public static void main(String[] args) {
       Connection con = null;
       Statement stmt = null;
       
       
       try {
    	   String dburl = "jdbc:mysql://localhost:3306/employee_info";
		con=DriverManager.getConnection(dburl, "root", "root");
	} catch (SQLException e) {
		// TODO Auto-generated catch block
		e.printStackTrace();
	}
       
       
      
       try {
    	   String q = "insert into employeedata value(4,'shivi',50000,'2021-09-19');";
           
		stmt=con.createStatement();
		
		int n = stmt.executeUpdate(q);
		System.out.println(n+"number of query affected");
	} catch (SQLException e) {
		// TODO Auto-generated catch block
		e.printStackTrace();
	}
       
       
       finally {
			if(stmt!=null)
			{
				try {
					stmt.close();
				} catch (SQLException e) {
					e.printStackTrace();
				}
			}
			if(con!=null)
			{
				try {
					con.close();
				} catch (SQLException e) {
					e.printStackTrace();
				}
			}
		}
	}

}
