package com.te.jdbc;

import java.io.FileInputStream;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.Statement;
import java.util.Properties;

public class SelectDynamic {

	public static void main(String[] data) {
		Connection con = null;
		PreparedStatement ps = null;
		ResultSet rs = null;

		Employee emp = new Employee();
		   
		   try {
			   FileInputStream fis = new FileInputStream("properties.properties");
			    Properties p = new Properties();
			    p.load(fis);
			con=DriverManager.getConnection(p.getProperty("dburl"), p.getProperty("user"),p.getProperty("pw"));
			String q = "select * from employeedata where id=?;";
            ps=con.prepareStatement(q);
			
			 ps.setInt(1,Integer.parseInt(data[0]));
			 rs=ps.executeQuery();
			 while(rs.next()) {
					emp.setId(rs.getInt("id"));
					emp.setName(rs.getString("name"));
					emp.setSal(rs.getInt("sal"));
					emp.setDoj(rs.getDate("doj"));
				}
				
				 System.out.println(emp.id+" "+emp.name+" "+emp.sal+" "+emp.doj);
			
				
			
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
			
		  
				
	}

}
