package com.te.jdbc;

import java.io.FileInputStream;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.Properties;

public class UpdateDynamic {

	public static void main(String[] data) {
		 Connection con = null;
	      Statement stmt = null;
	      PreparedStatement ps = null;
	      ResultSet rs = null;
	      
	      
	   	   FileInputStream fis;
		try {
			fis = new FileInputStream("properties.properties");
			 Properties p = new Properties();
		   	    p.load(fis);
		   	con=DriverManager.getConnection(p.getProperty("dburl"), p.getProperty("user"),p.getProperty("pw"));
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
	    
	    try {
	 	   String q = "update employeedata set name=? where id=?;";
	 	  ps=con.prepareStatement(q);
	 	  
	 	 ps.setString(1,data[0]);
			 ps.setInt(2,Integer.parseInt(data[1]));
			
			 rs=ps.executeQuery();
			
	        
			
			
		
			System.out.println("number of query affected");
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	    
	    
	    finally {
				if(stmt!=null)
				{
					try {
						stmt.close();
					} catch (SQLException e) {
						e.printStackTrace();
					}
				}
				if(con!=null)
				{
					try {
						con.close();
					} catch (SQLException e) {
						e.printStackTrace();
					}
				}
			}

		
	}

}
