package com.te.jdbc;

import java.io.Serializable;
import java.sql.Date;

public class Employee implements Serializable {
 int id;
String name;
int sal;
Date doj;
public Employee() {
	super();
	// TODO Auto-generated constructor stub
}
public Employee(int id, String name, int sal, Date doj) {
	super();
	this.id = id;
	this.name = name;
	this.sal = sal;
	this.doj = doj;
}
public int getId() {
	return id;
}
public void setId(int id) {
	this.id = id;
}
public String getName() {
	return name;
}
public void setName(String name) {
	this.name = name;
}
public int getSal() {
	return sal;
}
public void setSal(int sal) {
	this.sal = sal;
}
public Date getDoj() {
	return doj;
}
public void setDoj(Date doj) {
	this.doj = doj;
}


}
