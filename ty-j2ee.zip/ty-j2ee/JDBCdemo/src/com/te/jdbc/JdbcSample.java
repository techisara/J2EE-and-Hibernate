package com.te.jdbc;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;


import com.mysql.jdbc.Driver;

public class JdbcSample {

	public static void main(String[] args) {
		//load and register the driver
		Connection con=null;
		ResultSet rs = null;
		Statement stsm= null;
		
//		Driver driver = new Driver();
//		DriverManager.registerDriver(driver);
		
		try {
			Class.forName("com.mysql.jdbc.Driver").newInstance();
		} catch (InstantiationException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (IllegalAccessException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (ClassNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		
		
		// get connection via driver
		String dburl = "jdbc:mysql://localhost:3306/employee_info?user=root&password=root";
         try {
			con = DriverManager.getConnection(dburl);
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
         
         
         try {
        	 String query = "select * from employee;";
			stsm=con.createStatement();
			rs=stsm.executeQuery(query);
			while(rs.next()) {
				System.out.println(rs.getInt("eid"));
				System.out.println(rs.getInt("eid"));
				System.out.println(rs.getInt("eid"));
			}
			
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
         
         finally {
 			if(stsm!=null)
 			{
 				try {
 					stsm.close();
 				} catch (SQLException e) {
 					e.printStackTrace();
 				}
 			}
 			if(con!=null)
 			{
 				try {
 					con.close();
 				} catch (SQLException e) {
 					e.printStackTrace();
 				}
 			}
 		}
         
         
	}

}
